# [App](https://mlab-studio.com)
##### Author: Marko Radulovic
##### Version: 1.0.0
##### Link: [M Lab Studio](https://mlab-studio.com)

[App](https://mlab-studio.com) is an open source, admin dashboard template for [App](https://mlab-studio.com) created by [M Lab Studio](https://mlab-studio.com).

## Preview

[App](https://mlab-studio.com)

**[View Live Preview](#)**

## Status
*** Add description ***


## Download and Installation

To begin using this template, choose one of the following options to get started:
* 
* 
* 
* 

## Usage
*** Add description ***

### Basic Usage

After downloading...

### Advanced Usage

After installation, run `npm install` and then run `npm start` which will open up a preview of the template in your default browser, watch for changes to core template files, and live reload the browser when changes are saved. You can view the `scripts/` directory to see which tasks are included with the dev environment.

## Bugs and Issues

Have a bug or an issue with this template? [Open a new issue](#) here on GitHub or leave a comment

## Custom Builds

You can hire...

## About
*** Add description ***



* 
* 



* 
* 
* 


## Copyright and License

Copyright 2015-2020 [M Lab Studio](https://mlab-studio.com). Code released under the [MIT](#) license.
