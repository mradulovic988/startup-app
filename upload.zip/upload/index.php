<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="refresh" content="0;url=frontend/index.php">
    <title>SB Admin</title>
    <script language="javascript">
        window.location.href = "frontend/index.php"
    </script>
</head>

<body>
    Go to <a href="frontend/index.php">frontend/index.php</a>
</body>

</html>
