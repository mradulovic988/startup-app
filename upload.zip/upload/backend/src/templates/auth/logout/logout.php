<?php
include 'C:/xampp/htdocs/App/backend/config/Functions.php';
$function->logout(); // delete all session